package automationAssignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPageValidation {
	WebDriver driver;

    // Locators
    By nameField = By.id("name");
    By emailField = By.id("email");
    By passwordField = By.id("password");
    By confirmPasswordField = By.id("confirm_password");
    By submitButton = By.id("submit");
    By successMessage = By.id("successMessage");
    By errorMessage = By.id("errorMessage");

    public void LoginPageValidatio(WebDriver driver) {
        this.driver = driver;
    }

    public void enterName(String name) {
        driver.findElement(nameField).sendKeys(name);
    }

    public void enterEmail(String email) {
        driver.findElement(emailField).sendKeys(email);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).sendKeys(password);
    }

    public void enterConfirmPassword(String confirmPassword) {
        driver.findElement(confirmPasswordField).sendKeys(confirmPassword);
    }

    public void clickSubmit() {
        driver.findElement(submitButton).click();
    }

    public String getSuccessMessage() {
        return driver.findElement(successMessage).getText();
    }

    public String getErrorMessage() {
        return driver.findElement(errorMessage).getText();
    }
}